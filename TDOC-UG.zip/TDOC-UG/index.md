---
title: Руководство по ведению документации TDOC
publish: true
---
Настоящее руководство описывает единые правила оформления технической документации в хранилище (vault) Obsidian, публикуемом на портале TDOC. Документ предназначен для авторов, редакторов и сопровождающих документацию, а также для тех, кто создаёт собственное хранилище с нуля.

# Ссылки на скачивание:

 <a href="https://download-directory.github.io/?url=https%3A%2F%2Fgithub.com%2Fsemsig13-tech%2FTDOC-UG%2Ftree%2FFiles-for-download%2FUG-one-file" style="display:inline-block; padding:12px 24px; background-color:#33856E; color:#FFFFFF; text-decoration:none; border-radius:6px; font-weight:500; margin:8px;">Скачать руководство (MD)</a>
 

<a href="https://download-directory.github.io/?url=https%3A%2F%2Fgithub.com%2Fsemsig13-tech%2FTDOC-UG%2Ftree%2FFiles-for-download%2FTDOC-UG" style="display:inline-block; padding:12px 24px; background-color:#33856E; color:#FFFFFF; text-decoration:none; border-radius:6px; font-weight:500; margin:8px;">Скачать руководство (хранилище)</a>
 

# Навигация:

